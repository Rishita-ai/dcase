# Verification report - ToyCar
Generated 2026-11-09T17:19:55.009416 | smoke_test=False

## Dataset audit
- files audited: 1200 (all files: True)
- train source normal 990 (expected 990), train target normal 10 (expected 10)
- test source 100 = 50 normal + 50 anomaly; test target 100 = 50 normal + 50 anomaly
- sample rates [16000], channels [2], duration 11.0..11.0 s, unreadable 0, duplicate names 0, duplicate contents 0
- problems: none

## Split (protocol spec_full)
- recordings available: 990 source normal, 10 target normal | reserved for validation: 0 source | used for gradient updates: Model A 990 source, Model B 990 source + 10 target

## Models
- source_only: epochs run 100, selected epoch 100 (final epoch), train loss 0.47422, 14.6 min, device cuda
- source_target: epochs run 100, selected epoch 100 (final epoch), train loss 0.47515, 13.0 min, device cuda

## Mahalanobis statistics
- source_only: groups ['source_train', 'target_train', 'all_train'], numerically valid True
- source_target: groups ['source_train', 'target_train', 'all_train'], numerically valid True

## Verification checks
                                   0              1
machine                       ToyCar         ToyCar
variant                  source_only  source_target
checkpoint_exists               True           True
loads                           True           True
architecture_ok                 True           True
input_dim                       1280           1280
input_dim_ok                    True           True
output_dim_ok                   True           True
latent_dim_ok                   True           True
no_nan_random                   True           True
no_inf_random                   True           True
real_recordings_tested             3              3
finite_on_real_audio            True           True
reproducible                    True           True
mean_window_mse_normal      0.501124       0.485566
norm_stats_loadable             True           True
mahalanobis_stats_valid         True           True
mahalanobis_dims_ok             True           True
passed                          True           True

## RESULT: ALL PASSED