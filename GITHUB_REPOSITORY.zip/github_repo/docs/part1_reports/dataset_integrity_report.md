# Dataset integrity report
Generated 2026-11-10T12:15:10.371035

| machine | archive | status | src train (exp 990) | tgt train (exp 10) | test src n/a (exp 100) | test tgt n/a (exp 100) | sr | ch | duration s | unreadable | dup names | dup contents | problems |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| ToyCar | dev_ToyCar_r2.zip | COMPLETE | 990 | 10 | 50/50 | 50/50 | [16000] | [2] | 11.0..11.0 | 0 | 0 | 0 | none |
| ToyCarEmu | dev_ToyCarEmu.zip | COMPLETE | 990 | 10 | 50/50 | 50/50 | [16000] | [2] | 12.0..12.0 | 0 | 0 | 0 | none |
| Fan | dev_fan.zip | COMPLETE | 990 | 10 | 50/50 | 50/50 | [16000] | [2] | 10.0..10.0 | 0 | 0 | 0 | none |
| GearboxEmu | dev_gearboxEmu.zip | COMPLETE | 990 | 10 | 50/50 | 50/50 | [16000] | [2] | 10.0..10.0 | 0 | 0 | 0 | none |
| BearingEmu | dev_bearingEmu.zip | COMPLETE | 990 | 10 | 50/50 | 50/50 | [16000] | [2] | 10.0..10.0 | 0 | 0 | 0 | none |
| SlideRailEmu | dev_sliderEmu.zip | COMPLETE | 990 | 10 | 50/50 | 50/50 | [16000] | [2] | 10.0..10.0 | 0 | 0 | 0 | none |
| ValveEmu | dev_valveEmu.zip | COMPLETE | 990 | 10 | 50/50 | 50/50 | [16000] | [2] | 10.0..10.0 | 0 | 0 | 0 | none |

Supplemental (noise-only) clips present in the archives were not extracted and were not used. Test recordings were never used for training, validation or model selection.