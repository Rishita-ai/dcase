# PART 1 implementation report - DCASE 2026 Task 2 (full run)
Generated 2026-11-10 12:21:08 | device cpu | {'numpy': '2.4.6', 'pandas': '2.2.3', 'scipy': '1.16.3', 'matplotlib': '3.10.0', 'sklearn': '1.6.1', 'librosa': '0.11.0', 'soundfile': '0.14.0', 'torch': '2.14.1+cpu'}

## 1. Project overview
Noise-aware unsupervised anomalous sound detection (DCASE 2026 Task 2). Part 1 prepares, for each machine type, the dataset audit, two-channel log-Mel features, two trained Autoencoders (Experiment 1 / 3: Model A source-only, Model B source + target) and the normal-distribution statistics needed for Experiment 2 (Mahalanobis). Part 2 (teammate) performs the anomaly scoring and evaluation.

## 2. Dataset organisation (observed, not assumed)
Archives expected in /content/drive/MyDrive/DCASE_2026/Dataset: ['dev_ToyCar_r2.zip', 'dev_ToyCarEmu.zip', 'dev_fan.zip', 'dev_gearboxEmu.zip', 'dev_bearingEmu.zip', 'dev_sliderEmu.zip', 'dev_valveEmu.zip'].
Per machine the project document expects {'train_source_normal': 990, 'train_target_normal': 10, 'test_source': 100, 'test_target': 100, 'total': 1200}. Observed counts, sample rates, channels, durations, duplicates and problems: see Dataset_Audit/dataset_integrity_report.md (summary below).
| machine | archive | status | src train (exp 990) | tgt train (exp 10) | test src n/a (exp 100) | test tgt n/a (exp 100) | sr | ch | duration s | unreadable | dup names | dup contents | problems |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| ToyCar | dev_ToyCar_r2.zip | COMPLETE | 990 | 10 | 50/50 | 50/50 | [16000] | [2] | 11.0..11.0 | 0 | 0 | 0 | none |
| ToyCarEmu | dev_ToyCarEmu.zip | COMPLETE | 990 | 10 | 50/50 | 50/50 | [16000] | [2] | 12.0..12.0 | 0 | 0 | 0 | none |
| Fan | dev_fan.zip | COMPLETE | 990 | 10 | 50/50 | 50/50 | [16000] | [2] | 10.0..10.0 | 0 | 0 | 0 | none |
| GearboxEmu | dev_gearboxEmu.zip | COMPLETE | 990 | 10 | 50/50 | 50/50 | [16000] | [2] | 10.0..10.0 | 0 | 0 | 0 | none |
| BearingEmu | dev_bearingEmu.zip | COMPLETE | 990 | 10 | 50/50 | 50/50 | [16000] | [2] | 10.0..10.0 | 0 | 0 | 0 | none |
| SlideRailEmu | dev_sliderEmu.zip | COMPLETE | 990 | 10 | 50/50 | 50/50 | [16000] | [2] | 10.0..10.0 | 0 | 0 | 0 | none |
| ValveEmu | dev_valveEmu.zip | COMPLETE | 990 | 10 | 50/50 | 50/50 | [16000] | [2] | 10.0..10.0 | 0 | 0 | 0 | none |

Supplemental (noise-only) clips present in the archives were not extracted and were not used. Test recordings were never used for training, validation or model selection.

## 3. Preprocessing methodology
soundfile load (both channels, float32) -> resample to 16 kHz only if needed -> per channel Mel power spectrogram (n_fft 1024, hop 512, 128 mels, power 2) -> 20/power*log10(max(mel, eps)) -> channels concatenated (256-dim frame; Channel 1 = index 0, Channel 2 = index 1, neutral labels) -> nan_to_num -> per-dimension z-score with statistics of the model's own training recordings -> 5 consecutive frames flattened (1280-dim). Durations are not padded or cropped (frame-based model). Features are cached per machine (on Colab local disk). Supplemental noise clips are not used.
Deviation from the official baseline: the baseline reads both channels (mono: false) but uses only the first for features and applies no normalisation; this custom pipeline uses both channels and z-scoring. Results are therefore not comparable to the official baseline numbers.

## 4. Autoencoder
DCASEAutoencoder: 1280 -> 128 -> 128 -> 128 -> 128 -> 8 -> 128 -> 128 -> 128 -> 128 -> 1280, BatchNorm1d + ReLU after hidden layers, Linear output; 432 408 parameters; MSE loss; Adam lr 1e-3; batch 256; seed 42; fixed 100 epochs, final-epoch checkpoint, no validation set, no early stopping. One separate model per machine and per experiment variant (14 models for seven machines).

## 5. Experiments
Split protocol used in this run: **spec_full**. Model A uses ALL 990 source normals and Model B ALL 990 source + 10 target normals for gradient updates, fixed 100 epochs, final-epoch checkpoint; no recording is held out, so there is no validation loss (the AI_LAB.pdf / official-baseline protocol). Overfitting cannot be measured without a held-out set; training-loss convergence is monitored instead. Exact counts per machine are recorded in Preprocessing/<m>_split_manifest.json and in each checkpoint. Test recordings were never used for training, validation or model selection.
Experiment 2 (Mahalanobis) preparation: for each trained model, mean, covariance and regularised precision (Sigma + lambda I, lambda = 1e-3 trace/d, Cholesky-solved inverse) of (a) the 8-dim latent vectors and (b) the 256-dim residual frames, over the groups source_train (990 source normals), target_train (10 target normals), all_train (1000); all groups contain only normal recordings from train/. Dimensions, finiteness, positive definiteness, condition numbers and inverse accuracy are verified per group. MSE and Mahalanobis are kept as distinct scores; Part 2 chooses aggregation, group and thresholds.

## 6. Training results actually produced in this run
| machine | model | status | source_recordings | target_recordings | validation_recordings | epochs_run | selected_epoch | checkpoint_selection | final_train_loss | training_minutes | reused |
|---|---|---|---|---|---|---|---|---|---|---|---|
| ToyCar | source_only | COMPLETE | 990 | 0 | 0 | 100 | 100 | final epoch of fixed budget (no validation set) | 0.47422 | 14.60000 | False |
| ToyCar | source_target | COMPLETE | 990 | 10 | 0 | 100 | 100 | final epoch of fixed budget (no validation set) | 0.47515 | 13.00000 | False |
| ToyCarEmu | source_only | COMPLETE | 990 | 0 | 0 | 100 | 100 | final epoch of fixed budget (no validation set) | 0.49626 | 16.30000 | False |
| ToyCarEmu | source_target | COMPLETE | 990 | 10 | 0 | 100 | 100 | final epoch of fixed budget (no validation set) | 0.49648 | 14.40000 | False |
| Fan | source_only | COMPLETE | 990 | 0 | 0 | 100 | 100 | final epoch of fixed budget (no validation set) | 0.72936 | 13.70000 | False |
| Fan | source_target | COMPLETE | 990 | 10 | 0 | 100 | 100 | final epoch of fixed budget (no validation set) | 0.73116 | 11.90000 | False |
| GearboxEmu | source_only | COMPLETE | 990 | 0 | 0 | 100 | 100 | final epoch of fixed budget (no validation set) | 0.37557 | 13.60000 | False |
| GearboxEmu | source_target | COMPLETE | 990 | 10 | 0 | 100 | 100 | final epoch of fixed budget (no validation set) | 0.37702 | 11.90000 | False |
| BearingEmu | source_only | COMPLETE | 990 | 0 | 0 | 100 | 100 | final epoch of fixed budget (no validation set) | 0.47239 | 13.70000 | False |
| BearingEmu | source_target | COMPLETE | 990 | 10 | 0 | 100 | 100 | final epoch of fixed budget (no validation set) | 0.47178 | 12.00000 | False |
| SlideRailEmu | source_only | COMPLETE | 990 | 0 | 0 | 100 | 100 | final epoch of fixed budget (no validation set) | 0.46541 | 13.70000 | False |
| SlideRailEmu | source_target | COMPLETE | 990 | 10 | 0 | 100 | 100 | final epoch of fixed budget (no validation set) | 0.46383 | 12.00000 | False |
| ValveEmu | source_only | COMPLETE | 990 | 0 | 0 | 100 | 100 | final epoch of fixed budget (no validation set) | 0.52153 | 13.70000 | False |
| ValveEmu | source_target | COMPLETE | 990 | 10 | 0 | 100 | 100 | final epoch of fixed budget (no validation set) | 0.52192 | 12.00000 | False |
Losses are per-model normalised MSE and are not comparable between A and B or between machines. Lower loss means better reconstruction of normal sound, not better anomaly detection.
ToyCar: trained in this run or not yet processed.

## 7. Verification
| machine      | variant       | passed   | finite_on_real_audio   | reproducible   | norm_stats_loadable   | mahalanobis_stats_valid   |
|:-------------|:--------------|:---------|:-----------------------|:---------------|:----------------------|:--------------------------|
| BearingEmu   | source_only   | True     | True                   | True           | True                  | True                      |
| BearingEmu   | source_target | True     | True                   | True           | True                  | True                      |
| Fan          | source_only   | True     | True                   | True           | True                  | True                      |
| Fan          | source_target | True     | True                   | True           | True                  | True                      |
| GearboxEmu   | source_only   | True     | True                   | True           | True                  | True                      |
| GearboxEmu   | source_target | True     | True                   | True           | True                  | True                      |
| SlideRailEmu | source_only   | True     | True                   | True           | True                  | True                      |
| SlideRailEmu | source_target | True     | True                   | True           | True                  | True                      |
| ToyCarEmu    | source_only   | True     | True                   | True           | True                  | True                      |
| ToyCarEmu    | source_target | True     | True                   | True           | True                  | True                      |
| ToyCar       | source_only   | True     | True                   | True           | True                  | True                      |
| ToyCar       | source_target | True     | True                   | True           | True                  | True                      |
| ValveEmu     | source_only   | True     | True                   | True           | True                  | True                      |
| ValveEmu     | source_target | True     | True                   | True           | True                  | True                      |

## 8. Status per machine
| machine | status | notes | next action |
|---|---|---|---|
| ToyCar | COMPLETE |  | nothing |
| ToyCarEmu | COMPLETE |  | nothing |
| Fan | COMPLETE |  | nothing |
| GearboxEmu | COMPLETE |  | nothing |
| BearingEmu | COMPLETE |  | nothing |
| SlideRailEmu | COMPLETE |  | nothing |
| ValveEmu | COMPLETE |  | nothing |

## 9. Limitations
1. Only machines with status COMPLETE have trained models and statistics; nothing is reported for the others.
2. The experiments use the custom two-channel, normalised pipeline; no claim of reproducing the official baseline.
3. spec_full: no independent validation set exists, so no early stopping was possible and generalisation cannot be estimated from training loss; the final-epoch checkpoint of the fixed 100-epoch budget is the model. Threshold calibration for Part 2 must rely on training-split normals or on the optional cross-fitted calibration scores (see TRAINING_PROTOCOL_AND_CALIBRATION.md).
4. Anomaly detection quality is unknown until Part 2 evaluates on the test sets.
5. No cross-fitted calibration scores were generated in this run (CALIBRATION_FOLDS=0).
